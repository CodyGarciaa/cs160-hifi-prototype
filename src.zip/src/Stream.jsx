import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Button from './Button.jsx';


export default function Stream( {} ) {
 const navigate = useNavigate();


 const location = useLocation();
 const { movie_data } = location.state || {};
 const title = movie_data['tmdb_data']['title'];
 const id = movie_data['tmdb_data']['id'];
 const videoSRC = "https://multiembed.mov/?video_id=" + id + "&tmdb=1"
 const iframeRef = useRef(null);

 const goToMovie = () => {
   navigate('/MovieDescription', { state: { movie_data: movie_data } })
 }


 return (
   <div className="video-page-container">
     <h1 className="video-title">{title}</h1>
     <iframe src={videoSRC}></iframe>
     <Button className="back-btn" onClick={goToMovie}>
       <img src="https://cdn-icons-png.flaticon.com/512/566/566002.png"
       style={{ width: '20px', height: '20px' }}/>
     </Button>
   </div>
 );
};
