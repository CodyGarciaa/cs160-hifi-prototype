import React, { useEffect, useState } from "react";
import DropDownDescription from "./DropDownDescription.jsx";
import { useNavigate, useLocation } from "react-router-dom";
import Button from "./Button.jsx";
import "./PhobiaSceneDescription.css";
import WarningSing from "./warning-sign-icon-transparent-background-free-png 2.png";

export default function PhobiaSceneDescription({ phobiaArray }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { movie_data } = location.state || {};

  const [sceneTimes, setSceneTimes] = useState([]);
  const [sceneDescriptions, setSceneDescriptions] = useState([]);
  const [newMovie_data, setNewMovie_data] = useState(movie_data);

  const title = movie_data["tmdb_data"]["title"];
  const updated = movie_data['updated'];

  const goToMovieDescription = () => {
    navigate("/MovieDescription", { state: { movie_data: newMovie_data } });
  };

  useEffect(() => {
    const fetchSceneDescriptions = async () => {
      const response = await fetch(
        "https://noggin.rea.gent/faint-sloth-2045",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization:
              "Bearer rg_v1_di4dc7fq824gbvj1ixisyj1q03vreor8f4ry_ngk",
          },
          body: JSON.stringify({
            movie: title,
            phobia: phobiaArray.join(","),
          }),
        }
      ).then(response => response.json());

      const data_copy_helper = { ...newMovie_data };
      data_copy_helper['scenes'] = response;
      data_copy_helper['updated'] = true;

      // console.log("Fetched data:", response);
      setSceneTimes(response.time_list);
      setSceneDescriptions(response.description_list);
      setNewMovie_data(data_copy_helper);
    };

    if (title && phobiaArray.length > 0 & !updated) {
      fetchSceneDescriptions();
    }
  }, [title, phobiaArray]);

  return (
    <div className="phobia-scene-description">
      <Button className="back-btn" onClick={goToMovieDescription}>
        <img
          src="https://cdn-icons-png.flaticon.com/512/566/566002.png"
          style={{ width: "20px", height: "20px" }}
        />
      </Button>

      <h1>{title}</h1>
      <div>
      {/* <p> */}
        This movie has {sceneTimes.length} scenes with your trigger
        <br />
        <br />
        <div className="warning">
          <img src={WarningSing} className="warning-sign" />
          Scene descriptions may contain spoilers!
        </div>
      {/* </p> */}
      </div>
      {sceneTimes.map((time, index) => (
        <DropDownDescription
          key={index}
          buttonText={`Scene ${index + 1}`}
          popuptime={`${time}`}
          description={sceneDescriptions[index]}
        />
      ))}
    </div>
  );
}
